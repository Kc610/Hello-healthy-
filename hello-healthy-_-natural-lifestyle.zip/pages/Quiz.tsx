import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, RefreshCcw, Sparkles, Activity, Heart, Zap, Star } from 'lucide-react';
import { products } from '../data';
import ProductCard from '../components/ProductCard';
import { getWellnessTip } from '../services/geminiService';

interface Question {
  id: number;
  text: string;
  icon: React.ElementType;
  options: { label: string; value: string; recommendedTags: string[] }[];
}

const questions: Question[] = [
  {
    id: 1,
    text: "What is your primary wellness goal right now?",
    icon: Star,
    options: [
      { label: "Boost Energy", value: "energy", recommendedTags: ["Energy", "Coffee"] },
      { label: "Reduce Stress", value: "stress", recommendedTags: ["Stress Relief", "Relaxation", "Bath"] },
      { label: "Improve Immunity", value: "immunity", recommendedTags: ["Immunity", "Mushroom", "Natural"] },
      { label: "Weight Management", value: "weight", recommendedTags: ["Weight Loss", "Keto", "Sugar-Free"] },
    ]
  },
  {
    id: 2,
    text: "How would you describe your activity level?",
    icon: Activity,
    options: [
      { label: "High (Athlete/Intense)", value: "high", recommendedTags: ["Protein", "Sport", "Electrolytes"] },
      { label: "Moderate (Active Lifestyle)", value: "moderate", recommendedTags: ["Hydration", "Energy"] },
      { label: "Low (Desk Job/Light)", value: "low", recommendedTags: ["Herbal", "Gummies", "Wellness"] },
    ]
  },
  {
    id: 3,
    text: "Do you follow any specific diet?",
    icon: Heart,
    options: [
      { label: "Keto / Low Carb", value: "keto", recommendedTags: ["Keto", "Sugar-Free"] },
      { label: "Plant-Based", value: "vegan", recommendedTags: ["Natural", "Herbal", "Mushroom"] },
      { label: "No Restrictions", value: "none", recommendedTags: [] },
    ]
  }
];

const Quiz: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [tags, setTags] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [wellnessTip, setWellnessTip] = useState<string>("");

  const handleAnswer = (questionId: number, optionValue: string, optionTags: string[]) => {
    setAnswers(prev => ({ ...prev, [questionId]: optionValue }));
    setTags(prev => [...prev, ...optionTags]);

    if (currentStep < questions.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = async () => {
    setIsAnalyzing(true);
    
    // Get AI Tip
    const tip = await getWellnessTip(
      answers[1] || "General Health", 
      answers[2] || "Moderate", 
      answers[3] || "None"
    );
    setWellnessTip(tip);

    setTimeout(() => {
      setIsAnalyzing(false);
      setShowResults(true);
    }, 1500); // Simulate processing time for UX
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setAnswers({});
    setTags([]);
    setShowResults(false);
    setWellnessTip("");
  };

  // Filter products based on accumulated tags
  const getRecommendedProducts = () => {
    if (tags.length === 0) return products.slice(0, 3);

    // Score products based on tag matches
    const scoredProducts = products.map(p => {
      let score = 0;
      p.tags.forEach(tag => {
        if (tags.includes(tag)) score += 1;
      });
      return { product: p, score };
    });

    // Sort by score
    scoredProducts.sort((a, b) => b.score - a.score);

    return scoredProducts.slice(0, 3).map(sp => sp.product);
  };

  if (isAnalyzing) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-emerald-50 text-center px-4">
        <div className="relative w-24 h-24 mb-6">
          <div className="absolute inset-0 border-4 border-emerald-200 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-emerald-600 rounded-full border-t-transparent animate-spin"></div>
          <Sparkles className="absolute inset-0 m-auto text-emerald-600 w-8 h-8 animate-pulse" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Analyzing your profile...</h2>
        <p className="text-slate-500">Our AI is finding your perfect match.</p>
      </div>
    );
  }

  if (showResults) {
    const recommended = getRecommendedProducts();
    
    return (
      <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <span className="inline-block p-3 rounded-full bg-emerald-100 text-emerald-700 mb-4">
              <Check className="w-8 h-8" />
            </span>
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Your Wellness Score Unlocked!</h1>
            
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-emerald-100 max-w-2xl mx-auto mb-8 relative overflow-hidden">
               <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
               <div className="flex items-start gap-4 text-left">
                  <div className="bg-emerald-50 p-2 rounded-lg">
                     <Sparkles className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-1">Gemini AI Tip for You:</h3>
                    <p className="text-slate-600 italic">"{wellnessTip}"</p>
                  </div>
               </div>
            </div>

            <p className="text-lg text-slate-600">Based on your goals, we recommend these products:</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {recommended.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center">
            <button 
              onClick={resetQuiz}
              className="inline-flex items-center gap-2 text-slate-500 hover:text-emerald-600 font-medium transition-colors"
            >
              <RefreshCcw className="w-4 h-4" /> Retake Quiz
            </button>
          </div>
        </div>
      </div>
    );
  }

  const question = questions[currentStep];
  const progress = ((currentStep) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Progress Bar */}
      <div className="w-full h-2 bg-slate-100">
        <div 
          className="h-full bg-emerald-500 transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="flex-grow flex items-center justify-center p-4">
        <div className="max-w-xl w-full">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mb-6">
              <question.icon className="w-8 h-8" />
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">{question.text}</h2>
            <p className="text-slate-400">Question {currentStep + 1} of {questions.length}</p>
          </div>

          <div className="space-y-4">
            {question.options.map((option) => (
              <button
                key={option.value}
                onClick={() => handleAnswer(question.id, option.value, option.recommendedTags)}
                className="w-full p-6 text-left rounded-xl border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all group flex items-center justify-between"
              >
                <span className="font-semibold text-lg text-slate-700 group-hover:text-emerald-900">{option.label}</span>
                <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-emerald-500" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quiz;