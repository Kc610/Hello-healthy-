import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, User } from 'lucide-react';

const blogPosts = [
  {
    id: 1,
    title: "5 Morning Habits to Boost Your Energy Naturally",
    excerpt: "Stop reaching for that second cup of coffee. Here are 5 scientifically proven ways to wake up feeling refreshed and ready to tackle the day.",
    author: "Sarah Jenkins, Nutritionist",
    date: "March 15, 2024",
    image: "https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=800&q=80",
    category: "Wellness"
  },
  {
    id: 2,
    title: "The Ultimate Guide to Understanding Keto",
    excerpt: "Ketosis, macros, and fat bombs—oh my! We break down everything you need to know about starting a ketogenic lifestyle safely.",
    author: "Dr. Mark R.",
    date: "March 10, 2024",
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80",
    category: "Diet"
  },
  {
    id: 3,
    title: "Why Mushrooms Are the New Superfood",
    excerpt: "From Chaga to Lion's Mane, functional mushrooms are taking the wellness world by storm. Discover the benefits of these fungi friends.",
    author: "Elena Rodriguez",
    date: "March 05, 2024",
    image: "https://images.unsplash.com/photo-1616361993883-74b69324a13e?auto=format&fit=crop&w=800&q=80",
    category: "Nutrition"
  }
];

const Blog: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="bg-white border-b border-slate-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">The Wellness Journal</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg">Tips, guides, and inspiration for your journey to a healthier lifestyle.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow border border-slate-100 flex flex-col h-full">
              <div className="h-48 overflow-hidden relative">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                <span className="absolute top-4 left-4 bg-white/90 backdrop-blur text-emerald-700 text-xs font-bold px-3 py-1 rounded-full">
                  {post.category}
                </span>
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center gap-4 text-xs text-slate-400 mb-3">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {post.date}</span>
                  <span className="flex items-center gap-1"><User className="w-3 h-3" /> {post.author}</span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 mb-3 leading-tight hover:text-emerald-600 transition-colors cursor-pointer">
                  {post.title}
                </h2>
                <p className="text-slate-500 text-sm mb-6 line-clamp-3">
                  {post.excerpt}
                </p>
                <div className="mt-auto">
                  <button className="text-emerald-600 font-semibold text-sm flex items-center gap-1 hover:gap-2 transition-all">
                    Read Article <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;