import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, ShieldCheck, Truck, Users, Star, Zap, Moon, Heart, Flame } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { products } from '../data';
import BrandVideo from '../components/BrandVideo';

const Home: React.FC = () => {
  const featuredProducts = products.filter(p => p.category !== 'Bundles').slice(0, 4);
  const bundleProducts = products.filter(p => p.category === 'Bundles');

  return (
    <div className="flex flex-col gap-16 pb-20">
      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
          100% { transform: translateY(0px); }
        }
        @keyframes subtleZoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.05); }
        }
        .animate-fade-up {
          animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          opacity: 0;
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        .animate-subtle-zoom {
          animation: subtleZoom 20s ease-out forwards;
        }
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-500 { animation-delay: 0.5s; }
      `}</style>
      
      {/* Hero Section - Community & Quiz Focus */}
      <section className="relative overflow-hidden bg-emerald-900 min-h-[600px] flex items-center group">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80" 
            alt="Happy diverse group of people exercising" 
            className="w-full h-full object-cover opacity-30 mix-blend-overlay animate-subtle-zoom"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-900 via-transparent to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/80 to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full pt-20">
          <div className="max-w-3xl">
            <div className="animate-fade-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md text-emerald-100 text-sm font-medium mb-8 border border-white/20 hover:bg-white/20 transition-colors cursor-default">
                <Users className="w-4 h-4" />
                <span>Join 15,000+ wellness enthusiasts</span>
              </div>
            </div>
            
            <h1 className="animate-fade-up delay-100 text-5xl lg:text-7xl font-bold tracking-tight text-white mb-6 leading-[1.1]">
              Unlock Your <br/>
              <span className="bg-[#4ADE80] text-emerald-950 px-2 mt-2 inline-block">Wellness Score</span>
            </h1>
            
            <p className="animate-fade-up delay-200 text-xl text-emerald-100 mb-10 max-w-xl leading-relaxed">
              Not sure what your body needs? Take our 2-minute expert quiz to get a personalized health plan and discover your perfect match.
            </p>
            
            <div className="animate-fade-up delay-300 flex flex-col sm:flex-row gap-4">
              <Link 
                to="/quiz" 
                className="inline-flex justify-center items-center gap-2 bg-emerald-500 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-emerald-400 hover:scale-105 transition-all shadow-xl shadow-emerald-500/20 active:scale-95"
              >
                Take the Quiz <ArrowRight className="w-5 h-5" />
              </Link>
              <Link 
                to="/shop" 
                className="inline-flex justify-center items-center gap-2 bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-4 rounded-full font-bold text-lg hover:bg-white/20 hover:scale-105 transition-all active:scale-95"
              >
                Shop All Products
              </Link>
            </div>

            <div className="animate-fade-up delay-500 mt-12 flex items-center gap-4 text-emerald-200/80 text-sm">
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-emerald-900 bg-slate-200 overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                    <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="User" />
                  </div>
                ))}
              </div>
              <p className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /> 
                Rated 4.9/5 by our community
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Shop by Goal (Solutions) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-20 animate-fade-up delay-300">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 backdrop-blur-xl bg-white/95">
          <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">What are your health goals?</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Boost Energy', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-50', link: '/shop?category=Energy' },
              { label: 'Better Sleep', icon: Moon, color: 'text-indigo-500', bg: 'bg-indigo-50', link: '/shop?category=Personal%20Care' },
              { label: 'Immunity', icon: ShieldCheck, color: 'text-emerald-500', bg: 'bg-emerald-50', link: '/shop?category=Natural%20Extracts' },
              { label: 'Weight Mgmt', icon: Flame, color: 'text-rose-500', bg: 'bg-rose-50', link: '/shop?category=Specialty%20Supplements' },
            ].map((goal, idx) => (
              <Link key={idx} to={goal.link} className="flex flex-col items-center gap-3 p-6 rounded-2xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-100 hover:shadow-lg hover:-translate-y-1 group duration-300">
                <div className={`w-14 h-14 rounded-full ${goal.bg} ${goal.color} flex items-center justify-center group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                  <goal.icon className="w-7 h-7" />
                </div>
                <span className="font-semibold text-slate-700 group-hover:text-slate-900">{goal.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Video Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <BrandVideo />
      </section>

      {/* Benefits */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Leaf, title: "Clean Ingredients", desc: "No fillers, artificial junk, or hidden nasties." },
            { icon: ShieldCheck, title: "Lab Tested", desc: "Every batch is tested for purity and potency." },
            { icon: Truck, title: "Fast Shipping", desc: "Free delivery on orders over $50." },
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center text-center p-6 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4 transform group-hover:scale-110 transition-transform">
                <item.icon className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-slate-900 mb-2">{item.title}</h3>
              <p className="text-slate-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Exclusive Bundles Section */}
      <section className="bg-slate-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="mb-10 text-center">
             <span className="text-emerald-400 font-bold tracking-wider uppercase text-sm">Exclusive Offers</span>
             <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">Bundle & Save</h2>
             <p className="text-slate-400 mt-2">Get our best selling combinations for a fraction of the price.</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             {bundleProducts.map(product => (
               <div key={product.id} className="relative bg-slate-800 rounded-3xl p-1 overflow-hidden group">
                 <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-500 opacity-20 group-hover:opacity-30 transition-opacity"></div>
                 <div className="relative h-full bg-slate-800 rounded-[22px] flex flex-col sm:flex-row overflow-hidden border border-slate-700">
                    <div className="sm:w-1/2 relative h-64 sm:h-auto">
                      <img src={product.imageSrc} alt={product.title} className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-80 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="sm:w-1/2 p-6 flex flex-col justify-center">
                      <div className="inline-block bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md mb-3 w-max">
                        SAVE {product.compareAtPrice && Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)}%
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">{product.title}</h3>
                      <div className="text-slate-400 text-sm mb-4 line-clamp-3" dangerouslySetInnerHTML={{ __html: product.description.replace(/<[^>]*>?/gm, '') }} />
                      
                      <div className="mt-auto">
                        <div className="flex items-baseline gap-2 mb-4">
                          <span className="text-2xl font-bold text-emerald-400">${product.price}</span>
                          <span className="text-slate-500 line-through text-sm">${product.compareAtPrice}</span>
                        </div>
                        <Link to={`/product/${product.id}`} className="block w-full text-center bg-white text-slate-900 font-bold py-3 rounded-xl hover:bg-emerald-50 transition-colors">
                          View Bundle
                        </Link>
                      </div>
                    </div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">Community Favorites</h2>
            <p className="text-slate-500">The products everyone is talking about.</p>
          </div>
          <Link to="/shop" className="hidden sm:flex items-center gap-1 text-emerald-600 font-semibold hover:gap-2 transition-all group">
            View All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        
        <div className="mt-8 text-center sm:hidden">
           <Link to="/shop" className="inline-flex items-center gap-1 text-emerald-600 font-semibold">
            View All Products <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Community Section */}
      <section className="bg-slate-50 py-16 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">The Hello Healthy Life</h2>
          <p className="text-slate-600 mb-12 max-w-2xl mx-auto">Join a community of thousands transforming their health every day. Tag @HelloHealthy to be featured.</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
            {[
              "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=800&q=80",
              "https://images.unsplash.com/photo-1544367563-12123d8965cd?auto=format&fit=crop&w=800&q=80",
              "https://images.unsplash.com/photo-1552674605-469555942c77?auto=format&fit=crop&w=800&q=80",
              "https://images.unsplash.com/photo-1483721310020-03333e577078?auto=format&fit=crop&w=800&q=80"
            ].map((src, i) => (
              <div key={i} className={`aspect-square rounded-2xl overflow-hidden relative group animate-float`} style={{ animationDelay: `${i * 1.5}s` }}>
                <img src={src} alt="Community member" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-500"></div>
                <div className="absolute bottom-4 left-4 bg-white/90 px-2 py-1 rounded text-xs font-bold text-slate-900 opacity-0 group-hover:opacity-100 transition-opacity duration-300 translate-y-2 group-hover:translate-y-0 transform">
                  @hellohealthy
                </div>
              </div>
            ))}
          </div>

          <a href="#" className="inline-flex items-center gap-2 text-emerald-600 font-bold hover:text-emerald-700 hover:gap-3 transition-all">
            Join the Community <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="bg-emerald-900 rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden group">
           <div className="relative z-10 max-w-2xl mx-auto">
             <h2 className="text-3xl md:text-4xl font-bold mb-4">Start Your Journey Today</h2>
             <p className="text-emerald-100 mb-8 text-lg">Get expert wellness tips, exclusive early access to new drops, and 15% off your first order.</p>
             <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
               <input 
                 type="email" 
                 placeholder="Enter your email" 
                 className="flex-1 px-5 py-3 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-400 transition-shadow"
               />
               <button className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold px-6 py-3 rounded-xl transition-all hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/20">
                 Subscribe
               </button>
             </form>
           </div>
           
           {/* Circles */}
           <div className="absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-800 rounded-full blur-3xl opacity-50 animate-float" style={{ animationDuration: '8s' }}></div>
           <div className="absolute bottom-0 right-0 translate-x-1/2 translate-y-1/2 w-96 h-96 bg-emerald-600 rounded-full blur-3xl opacity-30 animate-float" style={{ animationDuration: '10s', animationDelay: '1s' }}></div>
        </div>
      </section>

    </div>
  );
};

export default Home;