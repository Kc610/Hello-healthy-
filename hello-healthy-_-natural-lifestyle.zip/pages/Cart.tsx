import React from 'react';
import { X, Minus, Plus, Trash2, ShoppingBag, ArrowRight, Lock, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Link, useNavigate } from 'react-router-dom';

const Cart: React.FC = () => {
  const { isCartOpen, toggleCart, items, removeFromCart, updateQuantity, cartTotal } = useCart();
  const navigate = useNavigate();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={toggleCart} />
      
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-white shadow-xl flex flex-col h-full animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" /> Your Cart
            </h2>
            <button onClick={toggleCart} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items */}
          <div className="flex-1 overflow-y-auto p-6">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8 text-slate-300" />
                </div>
                <div>
                  <p className="text-lg font-medium text-slate-900">Your cart is empty</p>
                  <p className="text-slate-500 mt-1">Looks like you haven't added anything yet.</p>
                </div>
                <button 
                  onClick={toggleCart}
                  className="mt-4 text-emerald-600 font-semibold hover:text-emerald-700"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              <ul className="space-y-6">
                {items.map((item) => (
                  <li key={item.id} className="flex py-2">
                    <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-xl border border-slate-100 bg-slate-50">
                      <img
                        src={item.imageSrc}
                        alt={item.title}
                        onError={(e) => e.currentTarget.src = `https://picsum.photos/seed/${item.id}/200/200`}
                        className="h-full w-full object-contain mix-blend-multiply"
                      />
                    </div>

                    <div className="ml-4 flex flex-1 flex-col">
                      <div>
                        <div className="flex justify-between text-base font-medium text-slate-900">
                          <h3 className="line-clamp-2 pr-4"><Link to={`/product/${item.id}`} onClick={toggleCart}>{item.title}</Link></h3>
                          <p className="ml-4">${(item.price * item.quantity).toFixed(2)}</p>
                        </div>
                        <p className="mt-1 text-sm text-slate-500">{item.category}</p>
                      </div>
                      <div className="flex flex-1 items-end justify-between text-sm">
                        <div className="flex items-center border border-slate-200 rounded-lg">
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 px-2 hover:bg-slate-50 text-slate-600 disabled:opacity-50"
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 font-medium text-slate-900">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 px-2 hover:bg-slate-50 text-slate-600"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFromCart(item.id)}
                          className="font-medium text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {items.length > 0 && (
            <div className="border-t border-slate-100 px-6 py-6 bg-slate-50">
              <div className="flex justify-between text-base font-medium text-slate-900 mb-4">
                <p>Subtotal</p>
                <p>${cartTotal.toFixed(2)}</p>
              </div>
              <p className="mt-0.5 text-sm text-slate-500 mb-6">Shipping and taxes calculated at checkout.</p>
              
              <button
                onClick={() => {
                   alert('Proceeding to checkout demo...'); 
                   toggleCart();
                }}
                className="w-full flex items-center justify-center rounded-xl border border-transparent bg-emerald-600 px-6 py-4 text-base font-bold text-white shadow-sm hover:bg-emerald-700 transition-all active:scale-95 mb-4"
              >
                Checkout <ArrowRight className="w-5 h-5 ml-2" />
              </button>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 gap-3 text-xs text-slate-600">
                <div className="flex items-center justify-center gap-1.5 bg-slate-50 border border-slate-100 py-2 rounded-lg">
                  <Lock className="w-3 h-3 text-emerald-600" />
                  <span className="font-medium">Secure Checkout</span>
                </div>
                <div className="flex items-center justify-center gap-1.5 bg-slate-50 border border-slate-100 py-2 rounded-lg">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  <span className="font-medium">Money-Back Guarantee</span>
                </div>
              </div>
              
              <div className="mt-4 flex justify-center items-center gap-2 opacity-60">
                 {['VISA', 'MC', 'AMEX', 'PAYPAL'].map(card => (
                   <div key={card} className="bg-white border border-slate-200 px-1.5 py-1 rounded text-[10px] font-bold text-slate-600 shadow-sm min-w-[32px] text-center">
                     {card}
                   </div>
                 ))}
              </div>

              <div className="mt-4 flex justify-center text-center text-sm text-slate-500">
                <p>
                  or{' '}
                  <button
                    type="button"
                    className="font-medium text-emerald-600 hover:text-emerald-500"
                    onClick={toggleCart}
                  >
                    Continue Shopping
                    <span aria-hidden="true"> &rarr;</span>
                  </button>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;