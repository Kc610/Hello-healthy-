import React from 'react';
import { Heart, Globe, Users, Award } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero */}
      <div className="bg-emerald-900 text-white py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Wellness for Everyone, Everywhere.</h1>
          <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
            We believe that good health shouldn't be complicated. Our mission is to provide clean, effective, and sustainable supplements that help you live your best life.
          </p>
        </div>
      </div>

      {/* Story */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Story</h2>
            <div className="space-y-4 text-slate-600 leading-relaxed">
              <p>
                Hello Healthy began with a simple question: "Why is the supplement aisle so confusing?" 
                Between unpronounceable ingredients and contradictory advice, we knew there had to be a better way.
              </p>
              <p>
                Founded in 2024, we set out to curate a selection of products that are not only effective 
                but transparent. We source the finest organic coffees, natural extracts, and scientifically-backed 
                vitamins to create a one-stop shop for your well-being.
              </p>
              <p>
                Today, we are more than just a store; we are a community of wellness enthusiasts dedicated to 
                helping you unlock your full potential, one healthy habit at a time.
              </p>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80" 
              alt="Team meeting" 
              className="rounded-3xl shadow-xl w-full object-cover h-[400px]"
            />
          </div>
        </div>
      </div>

      {/* Values */}
      <div className="bg-white py-20 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900">Why Choose Hello Healthy?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Heart, title: "Pure Ingredients", desc: "We never use artificial fillers. Only the good stuff." },
              { icon: Globe, title: "Sustainably Sourced", desc: "We care about the planet as much as your health." },
              { icon: Users, title: "Community First", desc: "We listen to you. Your feedback shapes our products." },
              { icon: Award, title: "Quality Tested", desc: "Third-party lab tested for safety and potency." },
            ].map((item, i) => (
              <div key={i} className="text-center p-6 bg-slate-50 rounded-2xl hover:bg-emerald-50 transition-colors">
                <div className="w-12 h-12 bg-white text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <item.icon className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2 text-slate-900">{item.title}</h3>
                <p className="text-slate-500 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};

export default About;