import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import Quiz from './pages/Quiz';
import Blog from './pages/Blog';
import About from './pages/About';
import ChatWidget from './components/ChatWidget';
import { CartProvider } from './context/CartContext';
import { Lock, ShieldCheck } from 'lucide-react';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const Footer = () => (
  <footer className="bg-white border-t border-slate-100 pt-16 pb-8">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div className="col-span-1 md:col-span-1">
          <div className="flex items-center gap-3 mb-4 text-emerald-800">
             <div className="w-10 h-10 flex items-center justify-center">
               <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
                 <path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.8l6 3v6.4l-6 3-6-3V7.8l6-3z" className="opacity-20"/>
                 <path d="M7 8h3v3.5h4V8h3v8h-3v-2.5h-4V16H7V8z" className="font-bold"/>
               </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black text-slate-800 tracking-tighter uppercase font-serif leading-none">
                Hello<br/>Healthy
              </span>
            </div>
          </div>
          <p className="text-slate-500 text-sm leading-relaxed mb-6">
            Empowering your journey to wellness with premium, nature-backed supplements and products.
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 inline-flex px-3 py-1.5 rounded-full border border-slate-100">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            <span>Official Partner of Healthy Living</span>
          </div>
        </div>
        <div>
          <h4 className="font-bold text-slate-900 mb-4">Shop</h4>
          <ul className="space-y-2 text-sm text-slate-600">
            <li><a href="#/shop" className="hover:text-emerald-600">All Products</a></li>
            <li><a href="#/shop?category=Supplements" className="hover:text-emerald-600">Supplements</a></li>
            <li><a href="#/shop?category=Coffee" className="hover:text-emerald-600">Coffee</a></li>
            <li><a href="#/shop?category=Bundles" className="hover:text-emerald-600">Bundles</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold text-slate-900 mb-4">Discover</h4>
          <ul className="space-y-2 text-sm text-slate-600">
            <li><a href="#/about" className="hover:text-emerald-600">About Us</a></li>
            <li><a href="#/blog" className="hover:text-emerald-600">Wellness Blog</a></li>
            <li><a href="#/quiz" className="hover:text-emerald-600">Take the Quiz</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold text-slate-900 mb-4">Legal</h4>
          <ul className="space-y-2 text-sm text-slate-600">
            <li><a href="#" className="hover:text-emerald-600">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-emerald-600">Terms of Service</a></li>
          </ul>
        </div>
      </div>
      <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-col sm:flex-row items-center gap-4 md:gap-8">
            <p className="text-slate-400 text-sm">© 2024 Hello Healthy. All rights reserved.</p>
            <div className="hidden sm:flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                    <Lock className="w-3 h-3" /> SSL Encrypted
                </div>
                 <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                    <ShieldCheck className="w-3 h-3" /> Money-Back Guarantee
                </div>
            </div>
        </div>
        <div className="flex gap-4">
          <div className="w-8 h-8 flex items-center justify-center bg-slate-100 rounded-full hover:bg-emerald-500 hover:text-white text-slate-400 transition-colors cursor-pointer">
             <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" /></svg>
          </div>
          <div className="w-8 h-8 flex items-center justify-center bg-slate-100 rounded-full hover:bg-emerald-500 hover:text-white text-slate-400 transition-colors cursor-pointer">
             <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg>
          </div>
          <div className="w-8 h-8 flex items-center justify-center bg-slate-100 rounded-full hover:bg-emerald-500 hover:text-white text-slate-400 transition-colors cursor-pointer">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772 4.902 4.902 0 011.772-1.153c.636-.247 1.363-.416 2.427-.465 1.067-.047 1.407-.06 4.123-.06h.08v.001zm0-2c-2.695 0-3.023.01-4.074.058-1.106.05-1.863.225-2.526.483a6.91 6.91 0 00-2.512 1.635 6.91 6.91 0 00-1.635 2.512c-.258.663-.433 1.42-.483 2.526C1.009 5.292 1 5.62 1 8.315v.63c0 2.695.01 3.023.058 4.074.05 1.106.225 1.863.483 2.526a6.91 6.91 0 001.635 2.512 6.91 6.91 0 002.512-1.635c.663.258 1.42.433 2.526.483 1.051.048 1.379.058 4.074.058h.63c2.695 0 3.023-.01 4.074-.058 1.106-.05 1.863-.225 2.526-.483a6.91 6.91 0 002.512-1.635 6.91 6.91 0 001.635-2.512c.258-.663.433-1.42.483-2.526.048-1.051.058-1.379.058-4.074v-.63c0-2.695-.01-3.023-.058-4.074-.05-1.106-.225-1.863-.483-2.526a6.91 6.91 0 00-1.635-2.512 6.91 6.91 0 00-2.512-1.635c-.663-.258-1.42-.433-2.526-.483C15.338 2.01 15.01 2 12.315 2zM12.315 8a4.315 4.315 0 110 8.63 4.315 4.315 0 010-8.63zm0 2a2.315 2.315 0 100 4.63 2.315 2.315 0 000-4.63zm5.838-4.17a1.44 1.44 0 11-2.88 0 1.44 1.44 0 012.88 0z" clipRule="evenodd" /></svg>
          </div>
        </div>
      </div>
    </div>
  </footer>
);

const App: React.FC = () => {
  return (
    <CartProvider>
      <Router>
        <ScrollToTop />
        <div className="min-h-screen bg-white flex flex-col">
          <Navbar />
          <Cart />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/product/:id" element={<ProductDetails />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/about" element={<About />} />
            </Routes>
          </main>
          <Footer />
          <ChatWidget />
        </div>
      </Router>
    </CartProvider>
  );
};

export default App;