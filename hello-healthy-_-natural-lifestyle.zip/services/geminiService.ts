import { GoogleGenAI } from "@google/genai";
import { products } from '../data';

let ai: GoogleGenAI | null = null;

// Helper to ensure we get a client with the latest key
const getAIClient = () => {
  // Always create a new instance if the key might have changed (e.g. via aistudio selection)
  if (process.env.API_KEY) {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return null;
};

export const streamChatResponse = async function* (
  userMessage: string, 
  history: { role: string; text: string }[]
) {
  const client = getAIClient();
  
  if (!client) {
    yield "Please configure your API_KEY to use the Health Assistant.";
    return;
  }

  // Create a context-aware system instruction
  const productContext = products.map(p => 
    `Product: ${p.title}\nPrice: $${p.price}\nCategory: ${p.category}\nDetails: ${p.description.replace(/<[^>]*>?/gm, '')}`
  ).join('\n\n');

  const systemInstruction = `You are a helpful and knowledgeable sales assistant for "Hello Healthy", an e-commerce store. 
  Your goal is to help customers find the right health products.
  
  Here is our product catalog:
  ${productContext}
  
  Rules:
  1. Only recommend products from the catalog above.
  2. Be friendly, professional, and concise.
  3. If asked about medical advice, strictly state that you cannot provide medical advice and they should consult a doctor, but you can explain what the product is generally used for based on the description.
  4. Keep answers under 100 words unless detailed comparison is asked.
  `;

  try {
    const model = 'gemini-3-pro-preview'; 
    const chat = client.chats.create({
      model: model,
      config: {
        systemInstruction: systemInstruction,
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }))
    });

    const result = await chat.sendMessageStream({ message: userMessage });

    for await (const chunk of result) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield "I'm having trouble connecting to the healthy brain network right now. Please try again later.";
  }
};

export const getWellnessTip = async (goal: string, activityLevel: string, diet: string): Promise<string> => {
  const client = getAIClient();
  if (!client) return "Stay hydrated and listen to your body! (Configure API Key for personalized tips)";

  try {
    const prompt = `
      User Profile:
      - Main Goal: ${goal}
      - Activity Level: ${activityLevel}
      - Diet Preference: ${diet}

      Provide a short, motivating, 1-sentence wellness tip specifically for this person. Do not mention specific products, just general health advice.
    `;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: prompt,
    });

    return response.text || "Small steps lead to big changes. Keep going!";
  } catch (error) {
    console.error("Gemini Wellness Tip Error:", error);
    return "Consistency is key to any health journey!";
  }
};

export const generateMarketingVideo = async (): Promise<string | null> => {
  const client = getAIClient();
  if (!client) throw new Error("API Key not found");

  try {
    let operation = await client.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: 'Cinematic commercial shot of fresh organic ingredients, matcha powder, and honey dripping, bright natural lighting, wellness aesthetic, 4k resolution, slow motion.',
      config: {
        numberOfVideos: 1,
        resolution: '1080p',
        aspectRatio: '16:9'
      }
    });

    // Poll for completion
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Check every 5s
      operation = await client.operations.getVideosOperation({ operation: operation });
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (videoUri && process.env.API_KEY) {
      // Append API key for playback
      return `${videoUri}&key=${process.env.API_KEY}`;
    }
    return null;
  } catch (error) {
    console.error("Veo Video Generation Error:", error);
    throw error;
  }
};