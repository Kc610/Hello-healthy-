import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Sparkles } from 'lucide-react';
import { useCart } from '../context/CartContext';

const Navbar: React.FC = () => {
  const { itemCount, toggleCart } = useCart();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/shop', label: 'Shop' },
    { path: '/about', label: 'About Us' },
    { path: '/blog', label: 'Blog' },
    { path: '/quiz', label: 'Take the Quiz' },
  ];

  const isActive = (path: string) => {
    if (path === '/shop') return location.pathname === '/shop' && !location.search;
    if (path.includes('?')) return location.search.includes(path.split('?')[1]);
    return location.pathname === path;
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-emerald-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-24">
          
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
             <div className="relative w-10 h-10 flex items-center justify-center text-emerald-800 transition-transform duration-300 group-hover:scale-105">
               {/* New Exclusive Bold Logo */}
               <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full drop-shadow-sm">
                 <path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.8l6 3v6.4l-6 3-6-3V7.8l6-3z" className="opacity-20"/>
                 <path d="M7 8h3v3.5h4V8h3v8h-3v-2.5h-4V16H7V8z" className="font-bold"/>
                 <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zm0-2a8 8 0 1 1 0-16 8 8 0 0 1 0 16z" className="opacity-10" />
               </svg>
             </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black text-slate-900 tracking-tighter uppercase font-serif leading-none group-hover:text-emerald-800 transition-colors">
                Hello<br/>Healthy
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.path}
                className={`text-sm font-bold tracking-wide uppercase transition-colors hover:text-emerald-700 ${
                  isActive(link.path) ? 'text-emerald-700 border-b-2 border-emerald-500' : 'text-slate-500'
                } ${link.path === '/quiz' ? 'text-emerald-600' : ''}`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <Link to="/quiz" className="hidden sm:flex items-center gap-1 text-xs font-bold text-white bg-emerald-600 px-5 py-2.5 rounded-full hover:bg-emerald-700 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Free Quiz</span>
            </Link>

            <button 
              onClick={toggleCart}
              className="relative p-2 text-slate-800 hover:text-emerald-600 transition-colors rounded-full hover:bg-emerald-50"
            >
              <ShoppingBag className="w-6 h-6" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
                  {itemCount}
                </span>
              )}
            </button>
            
            <button 
              className="md:hidden p-2 text-slate-800"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-emerald-100">
          <div className="px-4 pt-2 pb-6 space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.path}
                onClick={() => setIsMenuOpen(false)}
                className="block px-3 py-2 rounded-md text-base font-bold text-slate-700 hover:text-emerald-600 hover:bg-emerald-50 uppercase tracking-wide"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;