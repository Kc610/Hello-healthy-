import React, { useState, useEffect } from 'react';
import { Play, Loader2, Video, AlertCircle } from 'lucide-react';
import { generateMarketingVideo } from '../services/geminiService';

const BrandVideo: React.FC = () => {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    checkKey();
  }, []);

  const checkKey = async () => {
    // Use type assertion to avoid conflicts with global window.aistudio declaration
    if ((window as any).aistudio) {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    } else {
      // Fallback for dev environments without the special window object, assuming env var exists
      setHasKey(!!process.env.API_KEY);
    }
  };

  const handleSelectKey = async () => {
    if ((window as any).aistudio) {
      await (window as any).aistudio.openSelectKey();
      await checkKey();
    }
  };

  const handleGenerate = async () => {
    if (!hasKey) {
      await handleSelectKey();
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const url = await generateMarketingVideo();
      if (url) {
        setVideoUrl(url);
      } else {
        setError("Failed to generate video. Please try again.");
      }
    } catch (err) {
      setError("An error occurred while creating the video.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full bg-slate-900 rounded-3xl overflow-hidden relative shadow-2xl border border-slate-700">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 z-0"></div>

      <div className="relative z-10 w-full aspect-video flex flex-col items-center justify-center p-8 text-center">
        {videoUrl ? (
          <video 
            src={videoUrl} 
            controls 
            autoPlay 
            loop 
            className="w-full h-full object-cover rounded-xl shadow-lg border border-slate-600"
          />
        ) : (
          <div className="max-w-2xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-emerald-500/10 mb-6 animate-pulse">
              <Video className="w-10 h-10 text-emerald-400" />
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Experience the Essence
            </h2>
            <p className="text-slate-300 text-lg mb-8 max-w-lg mx-auto">
              Generate a unique, AI-crafted cinematic film that embodies the purity of our ingredients using Google's Veo.
            </p>

            {error && (
              <div className="flex items-center justify-center gap-2 text-red-400 bg-red-900/20 p-4 rounded-xl mb-6 border border-red-900/50">
                <AlertCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            )}

            {!hasKey ? (
              <div className="flex flex-col items-center gap-4">
                 <button
                  onClick={handleSelectKey}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 px-8 rounded-full transition-all hover:scale-105 shadow-lg shadow-emerald-500/20 flex items-center gap-3"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Connect Account to Generate
                </button>
                <p className="text-xs text-slate-500">
                  Requires a paid Google Cloud Project. <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="underline hover:text-emerald-400">Learn more</a>
                </p>
              </div>
            ) : (
              <button
                onClick={handleGenerate}
                disabled={isLoading}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 px-8 rounded-full transition-all hover:scale-105 shadow-lg shadow-emerald-500/20 flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed mx-auto"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Creating Experience...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    Generate Brand Film
                  </>
                )}
              </button>
            )}
            
            {isLoading && (
              <p className="mt-4 text-emerald-400/80 text-sm animate-pulse">
                This may take a minute. Veo is rendering your video...
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BrandVideo;