import React from 'react';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const [imageError, setImageError] = React.useState(false);

  const handleImageError = () => {
    setImageError(true);
  };

  const finalImageSrc = imageError 
    ? `https://picsum.photos/seed/${product.id}/400/400` 
    : product.imageSrc;

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-slate-100 hover:shadow-xl hover:shadow-emerald-900/5 transition-all duration-300 flex flex-col h-full">
      <Link to={`/product/${product.id}`} className="relative aspect-square overflow-hidden bg-slate-50">
        <img
          src={finalImageSrc}
          alt={product.title}
          onError={handleImageError}
          className="object-contain w-full h-full mix-blend-multiply group-hover:scale-105 transition-transform duration-500"
        />
        {product.compareAtPrice && product.compareAtPrice > product.price && (
          <div className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
            Save {Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)}%
          </div>
        )}
      </Link>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="text-xs font-semibold text-emerald-600 mb-2 uppercase tracking-wider">
          {product.category}
        </div>
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-slate-900 font-bold text-lg mb-1 leading-tight group-hover:text-emerald-700 transition-colors line-clamp-2">
            {product.title}
          </h3>
        </Link>
        <div className="text-slate-500 text-sm mb-4 line-clamp-2" dangerouslySetInnerHTML={{ __html: product.description.substring(0, 100) + '...' }} />
        
        <div className="mt-auto flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-xl font-bold text-slate-900">${product.price.toFixed(2)}</span>
            {product.compareAtPrice && (
              <span className="text-sm text-slate-400 line-through">${product.compareAtPrice.toFixed(2)}</span>
            )}
          </div>
          <button
            onClick={() => addToCart(product)}
            className="p-3 bg-slate-100 text-emerald-700 rounded-xl hover:bg-emerald-600 hover:text-white transition-all active:scale-95"
            aria-label="Add to cart"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;