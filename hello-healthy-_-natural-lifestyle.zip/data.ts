import { Product } from './types';

// Simulating a database with parsed data from the user's CSV
export const products: Product[] = [
  {
    id: "total-wellness-bundle",
    handle: "total-wellness-bundle",
    title: "The Total Wellness Bundle",
    description: "<p><strong>Save 20%</strong> when you buy together! The ultimate starter kit for a healthier you. Includes our signature Manuka Honey Coffee for energy, Collagen Gummies for beauty, and Ashwagandha for stress relief.</p>",
    vendor: "Hello Healthy store",
    category: "Bundles",
    price: 55.00,
    compareAtPrice: 69.90,
    imageSrc: "https://images.unsplash.com/photo-1556910103-1c02745a30bf?auto=format&fit=crop&w=800&q=80",
    tags: ["Bundle", "Deal", "Starter Kit"],
    weight: "1.2lb"
  },
  {
    id: "workout-warrior-bundle",
    handle: "workout-warrior-bundle",
    title: "Workout Warrior Pack",
    description: "<p><strong>Exclusive Deal!</strong> Everything you need to crush your gym goals. Contains Energy Powder (Melon), Hydration Powder (Passion Fruit), and Keto-5 Fat Burner.</p>",
    vendor: "Hello Healthy store",
    category: "Bundles",
    price: 85.00,
    compareAtPrice: 102.88,
    imageSrc: "https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?auto=format&fit=crop&w=800&q=80",
    tags: ["Bundle", "Sport", "Energy"],
    weight: "1.5lb"
  },
  {
    id: "manuka-honey-coffee-4oz",
    handle: "manuka-honey-coffee-4oz",
    title: "Manuka Honey Coffee 4oz",
    description: "<p>Our Manuka Honey Coffee is something you don’t want to miss out on. With medium-dark roasted Arabica beans glazed in authentic Manuka honey from New Zealand, this coffee is sure to be your go-to every morning.</p>",
    vendor: "Hello Healthy store",
    category: "Coffee & Tea",
    price: 19.99,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758062156308-generated-label-image-0.jpg?v=1758062356",
    tags: ["Coffee", "Honey", "Energy"],
    weight: "0.25lb"
  },
  {
    id: "energy-powder-melon-creamsicle",
    handle: "energy-powder-melon-creamsicle",
    title: "Energy Powder (Melon Creamsicle)",
    description: "<p>Tired of the highs and lows from traditional energy drinks? Discover a balanced boost with our Energy Powder, featuring a great sugar free taste formula crafted for those who demand a smooth, sustained lift.</p>",
    vendor: "Hello Healthy store",
    category: "Pre-Workout Supplements",
    price: 34.99,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758061341311-generated-label-image-0.jpg?v=1758061376",
    tags: ["Energy", "Pre-Workout", "Sugar-Free"],
    weight: "0.31lb"
  },
  {
    id: "keto-5",
    handle: "keto-5",
    title: "Keto-5 Fat Burner",
    description: "<p>Keto-5 helps the body burn fat effectively by entering the body into the ketosis metabolic state. Usually, the body uses glycogen stores as its fuel source and stores fat cells through lipogenesis.</p>",
    vendor: "Hello Healthy store",
    category: "Specialty Supplements",
    price: 32.90,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758059510126-generated-label-image-0.jpg?v=1758059524",
    tags: ["Keto", "Weight Loss", "Supplements"],
    weight: "0.25lb"
  },
  {
    id: "chaga-mushroom",
    handle: "chaga-mushroom",
    title: "Chaga Mushroom Capsules",
    description: "<p>Chaga Mushroom Capsules are loaded with essential nutrients for optimized body functioning. The most notable of these nutrients are phytochemicals.</p>",
    vendor: "Hello Healthy store",
    category: "Natural Extracts",
    price: 29.90,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044056015-generated-label-image-0.jpg?v=1758045641",
    tags: ["Mushroom", "Immunity", "Natural"],
    weight: "0.2lb"
  },
  {
    id: "collagen-gummies-adult",
    handle: "collagen-gummies-adult",
    title: "Collagen Gummies (Adult)",
    description: "<p>Collagen Gummies are for those looking for healthy sweet snacks. These are the perfect replacement for traditional sugar gummies on the market since they provide vital protein.</p>",
    vendor: "Hello Healthy store",
    category: "Proteins & Blends",
    price: 25.90,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044149225-generated-label-image-0.jpg?v=1758045644",
    tags: ["Beauty", "Skin", "Gummies"],
    weight: "0.56lb"
  },
  {
    id: "bee-bread-powder",
    handle: "bee-bread-powder",
    title: "Bee Bread Powder",
    description: "<p>Bee Pearl Powder is a smoothie additive consisting of concentrated bee bread, propolis, and royal jelly.</p>",
    vendor: "Hello Healthy store",
    category: "Natural Extracts",
    price: 47.90,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044324225-generated-label-image-0.jpg?v=1758045649",
    tags: ["Immunity", "Energy", "Natural"],
    weight: "0.3lb"
  },
  {
    id: "hydration-powder-passion-fruit",
    handle: "hydration-powder-passion-fruit",
    title: "Hydration Powder (Passion Fruit)",
    description: "<p>Elevate your hydration routine with Passion Fruit HYDRATION, a delicious drink that combines essential electrolytes to keep you hydrated and energized.</p>",
    vendor: "Hello Healthy store",
    category: "Specialty Supplements",
    price: 34.99,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044014479-generated-label-image-0.jpg?v=1758045638",
    tags: ["Hydration", "Electrolytes", "Sport"],
    weight: "0.43lb"
  },
  {
    id: "calming-lavender-soap",
    handle: "calming-lavender-soap",
    title: "Calming Lavender Soap",
    description: "<p>Embrace the serene and soothing qualities of our Calming Lavender Soap, carefully crafted for those with sensitive, delicate, or complex skin types.</p>",
    vendor: "Hello Healthy store",
    category: "Personal Care",
    price: 14.99,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044303452-generated-label-image-0.jpg?v=1758045649",
    tags: ["Beauty", "Bath", "Relaxation"],
    weight: "4oz"
  },
  {
    id: "ashwagandha",
    handle: "ashwagandha",
    title: "Ashwagandha",
    description: "<p>Ashwagandha is an ancient herb used in Ayurvedic medicine. It is most well-known as a powerful adaptogen that helps individuals calm their stress levels.</p>",
    vendor: "Hello Healthy store",
    category: "Natural Extracts",
    price: 23.99,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044025355-generated-label-image-0.jpg?v=1758045639",
    tags: ["Stress Relief", "Herbal", "Ayurveda"],
    weight: "0.25lb"
  },
  {
    id: "dog-waterless-shampoo",
    handle: "dog-waterless-shampoo",
    title: "Dog Waterless Shampoo",
    description: "<p>Avoid the hassle of having to give your pup a full bath! With our dog waterless shampoo, you can clean your dog's fur easily, with no water.</p>",
    vendor: "Hello Healthy store",
    category: "Pet",
    price: 17.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0678/4928/9863/files/1758044291295-generated-label-image-0.jpg?v=1758045650",
    tags: ["Pet Care", "Dogs", "Grooming"],
    weight: "0.3lb"
  }
];