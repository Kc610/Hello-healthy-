export interface Product {
  id: string;
  handle: string;
  title: string;
  description: string; // Raw HTML from CSV
  vendor: string;
  category: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  tags: string[];
  weight?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isLoading?: boolean;
}